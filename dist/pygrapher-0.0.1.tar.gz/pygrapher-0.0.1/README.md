# excel-like-python-curve-fitter
Use python to do curve fitting as easy as excel

Still working on it......
